var interval = 3000;
var numberOfBlocks = 9;
var numberOfTarget = 3;
var targetBlocks = [];
var selectedBlocks = [];
var timer;

document.observe('dom:loaded', function(){

});

function stopToStart(){
    stopGame();
    startToSetTarget();
}

function stopGame(){

}

function startToSetTarget(){

}

function setTargetToShow(){

}

function showToSelect(){

}

function selectToResult(){

}