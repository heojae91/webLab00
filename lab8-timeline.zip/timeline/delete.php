<?php
# Ex 5 : Delete a tweet
try {
    /*
    call delete function
    header("Location:index.php");
    */
} catch(Exception $e) {
    /* header("Loaction:error.php"); */
}
?>
